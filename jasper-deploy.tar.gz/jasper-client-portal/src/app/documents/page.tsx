'use client'

import ComingSoon from '@/components/ComingSoon'
import { FileText } from 'lucide-react'

export default function DocumentsPage() {
  return (
    <ComingSoon
      title="Documents"
      description="Securely access, share, and manage all your project documents and deliverables."
      icon={<FileText className="w-10 h-10 text-jasper-emerald" />}
      features={[
        'Download financial models and reports',
        'Upload supporting documents',
        'Version history for all files',
        'Secure document sharing',
        'Organize files by project',
      ]}
    />
  )
}
