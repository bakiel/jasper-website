export { DocumentManager } from './DocumentManager'
